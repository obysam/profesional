<footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>
                        <li>
                            <a href="#">
                                Home
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Company
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                Portfolio
                            </a>
                        </li>
                        <li>
                            <a href="#">
                               Blog
                            </a>
                        </li>
                    </ul>
                </nav>
                <p class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> <a href="http://www.creative-tim.com">Creative Tim</a>, made with love for a better web
                </p>
            </div>
        </footer>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="<?=base_url();?>assets/js/jquery-1.10.2.js" type="text/javascript"></script>
    <script src="<?=base_url();?>assets/js/jquery-ui.min.js" type="text/javascript"></script>
       <script src="<?=base_url();?>assets/js/knockout.min.js"></script>
    <script src="<?=base_url();?>assets/js/knockout.mapping-latest.js"></script>
  
    <script src="<?=base_url();?>assets/js/underscore.min.js"></script>
    <script src="<?=base_url();?>assets/js/jquery.easy-autocomplete.min.js"></script>

    <script src="<?=base_url();?>assets/js/sweet-alert.min.js"></script>
	<script src="<?=base_url();?>assets/js/bootstrap.min.js" type="text/javascript"></script>  
	<script src="<?=base_url();?>assets/js/bootstrap-checkbox-radio-switch.js"></script>
  <script src="<?=base_url();?>assets/js/select2.full.min.js"></script>
    
	<!--  Charts Plugin -->
	<script src="<?=base_url();?>assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="<?=base_url();?>assets/js/bootstrap-notify.js"></script>

    
</html>