<center><h2>Konfirmasi Email <small style="color:grey"><?=$email;?></small></h2></center>
<br>
<p style="font-family: arial">Anda Telah melakukan Pendaftaran untuk menjadi member Profesional.id. Satu langkah lagi untuk mengaktifkan akun anda dan mulai tunjukan bakat anda pada Dunia.</p>
<p>Klik Link berikut atau Copy dan paste pada URL Browser Anda <a href="http://www.profesional.id/login/confirm/<?=$auth;?>">http://www.profesional.id/Login/confirm/<?=$auth;?></a></p>

<br>
<p style="text-align: right">Jika anda tidak merasa mendaftar, silahkan abaikan pesan ini
<br>Terima Kasih
<br>
Admin Profesional.id
</p>
