                <div class="row biodata">
                <div class="col-md-8 col-xs-12 col-md-offset-2">
                     <div class="card">
                            <div class="header">
                                <h4 class="title">Form Biodata</h4>
                                <p class="category">Isikan data dengan jelas sehingga memudahkan orang membaca CV anda</p>
                            </div>
                            <div class="content">
                                <form class="form-horizontal" id="form-biodata" data-bind="with: model.Biodata">
                                    <fieldset>

                                    <!-- Text input-->
                                    <div class="form-group">
                                      <label class="col-md-4 control-label topplus10" for="nama">Nama Lengkap</label>  
                                      <div class="col-md-6">
                                      <input id="nama" name="nama" type="text" placeholder="" class="form-control input-md" required="" value="" data-bind="value:  nama">
                                        
                                      </div>
                                    </div>

                                    <div class="form-group">
                                      <label class="col-md-4 control-label topplus10" for="nama">Jenis Kelamin</label>  
                                      <div class="col-md-6">
                                         <input type="radio" class="topplus10" name="jenisKelamin" id="pria" value="pria" data-bind="value:'pria',checked: jenisKelamin">Pria
                                         <input type="radio" class="topplus10" name="jenisKelamin"  id="wanita" value="wanita" data-bind="value:'wanita',checked: jenisKelamin">wanita

                                      </div>
                                    </div>

                                      <div class="form-group">
                                      <label class="col-md-4 control-label topplus10" for="nama">Status</label>  
                                      <div class="col-md-6">
                                        <input type="radio" name="status" id="menikah" value="married" data-bind="value:'married',checked: statusPernikahan">Menikah
                                         <input type="radio" name="status" id="belum_menikah" value="single" data-bind="value:'single',checked: statusPernikahan">Belum Menikah
                 
                                      </div>
                                    </div>

                                    <!-- Text input-->
                                    <div class="form-group">
                                      <label class="col-md-4 control-label topplus10" for="tempat_lahir">Tempat / Tgl Lahir</label>  
                                      <div class="col-md-4">
                                        <input type="text" name="tempat_lahir" id="tempat_lahir" class="form-control" data-bind="value: tempat_lahir" value="">
                                    <!--   <input id="domisili" name="domisili" type="text" placeholder="Domisili saat ini" class="form-control input-md" required="" value="" data-bind="value:  domisili">
                                       -->  
                                        
                                      </div><div class="col-md-2">
                                      <input id="tanggal_lahir" name="tanggal_lahir" type="text"  class="form-control input-md" required="" value="" data-bind="value: tanggal_lahir">
                                        
                                      </div>
                                    </div>

                      
                                    <!-- Text input-->
                                    <div class="form-group">
                                      <label class="col-md-4 control-label topplus10" for="domisili">Domisili</label>  
                                      <div class="col-md-6">
                                      <input type="text" name="domisili" id="domisili" class="form-control" data-bind="value: domisili" value="">
                                    <!--   <input id="domisili" name="domisili" type="text" placeholder="Domisili saat ini" class="form-control input-md" required="" value="" data-bind="value:  domisili">
                                       -->  
                                      </div>
                                    </div>

                                    <!-- File Button --> 
                                    <div class="form-group">
                                      <label class="col-md-4 control-label" for="foto">Foto</label>
                                      <div class="col-md-6">
                                        <input id="foto" name="foto" class="input-file" type="file" data-bind="value: model.fileName, fileUpload: model.fileName">
                                      </div>
                                    </div>

                                    </fieldset>
                                    </form>

                                <div class="footer">
                                    <div class="col-md-12">
                                        <center>
                                            <a href="#" id="simpan-biodata" class="btn btn-primary"><i class="fa fa-save" aria-hidden="true"></i> Simpan</a>
                                        </center>
                                    </div>
                                    <br>
                                    <br>
                                </div>
                            </div>
                        </div>
                </div>
            </div>

                </div>
        </div>

        
