                <div class="row sosmed">
                <div class="col-md-8 col-xs-12 col-md-offset-2">
                     <div class="card">
                            <div class="header">
                                <h4 class="title">Data Akun Social Media Anda</h4>
                            </div>
                            <div class="content">
                                <form class="form-horizontal" id="form-sosmed" data-bind="with: model.sosmed">
                                    <fieldset>
                                    <legend><center>Wajib menggunakan <u>http://</u></center>
                                    <center><span style="font-size:11px;color:grey">Cantumkan yang anda miliki dan aktif saja</span></center></legend>
                                    <!-- Text input-->
                                    <div class="form-group">
                                      <label class="col-md-4 control-label topplus10" for="facebook">facebook</label>  
                                      <div class="col-md-6">
                                      <div class="input-group">
                                      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-facebook" style="color:blue"></i></span>
                                      <input id="facebook" name="facebook" type="text" placeholder="http://www.facebook.com/username" class="form-control input-md" required="" value="" data-bind="value:  facebook">                       
                                      </div>
                                      </div>
                                    </div>

                                     <div class="form-group">
                                      <label class="col-md-4 control-label topplus10" for="twitter">twitter</label>  
                                      <div class="col-md-6">
                                      <div class="input-group">
                                      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-twitter" style="color:blue"></i></span>
                                      <input id="twitter" name="twitter" type="text" placeholder="http://www.twitter.com/username" class="form-control input-md" required="" value="" data-bind="value:  twitter">                       
                                      </div>
                                      </div>
                                    </div>

                                     <div class="form-group">
                                      <label class="col-md-4 control-label topplus10" for="instagram">instagram</label>  
                                      <div class="col-md-6">
                                      <div class="input-group">
                                      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-instagram" style="color:blue"></i></span>
                                      <input id="instagram" name="instagram" type="text" placeholder="http://www.instagram.com/username" class="form-control input-md" required="" value="" data-bind="value:  instagram">                       
                                      </div>
                                      </div>
                                    </div>

                                     <div class="form-group">
                                      <label class="col-md-4 control-label topplus10" for="linkedin">linkedin</label>  
                                      <div class="col-md-6">
                                      <div class="input-group">
                                      <span class="input-group-addon" id="basic-addon1"><i class="fa fa-linkedin" style="color:blue"></i></span>
                                      <input id="linkedin" name="linkedin" type="text" placeholder="http://www.linkedin.com/username" class="form-control input-md" required="" value="" data-bind="value:  linkedin">                       
                                      </div>
                                      </div>
                                    </div>

                               
                                    </fieldset>
                                    </form>

                                <div class="footer" style="padding-bottom: 35px">
                                    <div class="col-md-12" >
                                        <center>
                                            <a href="#" id="simpan-sosmed" class="btn btn-primary"><i class="fa fa-save" aria-hidden="true"></i> Simpan</a>

                                               <p class="category" style="padding-top: 15px">HRD seringkali menseleksi karakter calon karyawan via akun Social Media. <br>Ide bagus untuk selalu memuat konten positif di Social Media Anda</p>
                                        </center>
                                    </div>
                                    <br>
                                    <br>
                                </div>
                            </div>
                        </div>
                </div>
            </div>

                </div>
        </div>

        
