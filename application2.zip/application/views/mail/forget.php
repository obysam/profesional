<center><h2>Konfirmasi Lupa Password <small style="color:grey"><?=$email;?></small></h2></center>
<br>
<p style="font-family: arial">Anda Telah melakukan request untuk reset Password pada akun profesional.id anda. </p>
<p>Klik Link berikut atau Copy dan paste pada URL Browser Anda <a href="http://www.profesional.id/Login/forgetauth/<?=$auth;?>">http://www.profesional.id/Login/forgetauth/<?=$auth;?></a></p>

<br>
<p style="text-align: right">Jika anda tidak merasa melakukan request, silahkan abaikan pesan ini
<br>Terima Kasih
<br>
Admin Profesional.id
</p>
